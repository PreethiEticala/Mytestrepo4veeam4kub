#-------Set the environment variables"
export MY_CLUSTER=gke4yong1 #Customize your favorite cluster name
export MY_MACHINE_TYPE=e2-standard-2 #Customize your favorite machine type
export MY_REGION=us-central1 #Customize your favorite region
export MY_ZONE=us-central1-f #Customize your favorite zone
export MY_BUCKET=k10bucket4yong1 #Customize your favorite bucket
export MY_OBJECT_STORAGE_PROFILE=mygcs1 #Customize your favorite profile name

